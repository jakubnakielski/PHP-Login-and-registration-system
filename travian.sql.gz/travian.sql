-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 15, 2019 at 12:34 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `travian`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` text COLLATE utf8_polish_ci NOT NULL,
  `email` text COLLATE utf8_polish_ci NOT NULL,
  `password` text COLLATE utf8_polish_ci NOT NULL,
  `wood` int(11) NOT NULL,
  `iron` int(11) NOT NULL,
  `stone` int(11) NOT NULL,
  `corn` int(11) NOT NULL,
  `premium` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `login`, `email`, `password`, `wood`, `iron`, `stone`, `corn`, `premium`) VALUES
(18, 'wojtek12', 'wojtek12@wojtek.pl', '$2y$10$W6NAeF5Ys/cpaEXSzPLe/e955.85w3OSnMUw0ZsoNLXaetM3Wn.Qm', 100, 100, 100, 100, '0000-00-00 00:00:00'),
(19, 'jakubnakielski', 'jakubnakielski2@gmail.com', '$2y$10$xVGOt11ip5OBPu/6ttCDQ.iHPt5ZYcmWz.8j3lT9lAGY9xUCgt7li', 100, 100, 100, 100, '0000-00-00 00:00:00'),
(20, 'wojtyla', 'wojtyla@jakub.com', '$2y$10$G3DeJYNy.DgIvbM0iLSyzOxmZHNHFVwpCDN2wStfeYbkkyBVpXjqe', 100, 100, 100, 100, '0000-00-00 00:00:00'),
(21, 'userTestowy', 'userTestowy@userTestowy.pl', '$2y$10$26v9nnZEm5YF1mVfhcMZr.moATJwb2VDQaFLq8kFhTEQ/j.2PTl56', 100, 100, 100, 100, '0000-00-00 00:00:00'),
(22, 'pozdrawiam', 'pozdrawiam@pozdrawiam.pl', '$2y$10$ZBk662/QbSvAh5udaglwmuMSDxsk5zZy2OE1FFAMqeUhO/IfA.mnm', 100, 100, 100, 100, '0000-00-00 00:00:00'),
(23, 'asdfasdf', 'asdfasdf@wp.pl', '$2y$10$RIULFTi1gw6viGPbXD4poeJofUYBt7aXjtKG1S6.O.FJNpMzJR9Ou', 100, 100, 100, 100, '0000-00-00 00:00:00'),
(25, 'grzegorz', 'grzegorz@grzegorz.pl', '$2y$10$5.BDwpbtfCQ2SqpE1Ue0tehc6ArWPv7pU7D7ulc6VGEtOs0At7kxi', 100, 100, 100, 100, '0000-00-00 00:00:00'),
(26, 'joannajoanna', 'joanna@joanna.pl', '$2y$10$Gd/mP9AtChZEgBChCedsSudMmu59SllSIyQhuNLZlyehnYaECFUBa', 100, 100, 100, 100, '0000-00-00 00:00:00'),
(27, 'bartlomiej', 'bartlomiej@bartlomiej.pl', '$2y$10$fbKZrnU4wefalclrlAbPP.MJDClIDq0IHKTJ4yDBs3yd2TePe0wAu', 100, 100, 100, 100, '0000-00-00 00:00:00'),
(28, 'nakielski', 'nakielski@nakielski.pl', '$2y$10$oxgJI/cHC8BPw2Xg/fSQnuYO3z3.m2VhfQ4QkWAhVo6MItsIyVb4q', 100, 100, 100, 100, '0000-00-00 00:00:00'),
(29, 'nakielskij', 'Pozdrawiam@Pozdrawiam.pl', '$2y$10$ntvc.WytpdlXksFUEqFW0ecPe0i87DhYwSsgjEcg4h2FO9C6/naHy', 100, 100, 100, 100, '0000-00-00 00:00:00'),
(30, 'jakubjakub', 'jakubjakub@jakubjakub.pl', '$2y$10$NFMbW4rDK6R./1xSLv87He194unPLv/6p8Cot3VoT6b0QmmA9Lwi6', 100, 100, 100, 100, '0000-00-00 00:00:00'),
(31, 'qwerty123', 'agafraz@gmail.com', '$2y$10$U4ja9S1VGhvs6syGP9BYkOMPT7eOoC/PkQGf7ZmZM9u8GI34GWE0W', 100, 100, 100, 100, '0000-00-00 00:00:00'),
(32, 'nowyuser', 'nowyuser@gmail.com', '$2y$10$q1RZtwj51uJtsR8V6A9MU.gqBemE/AESAn1AkKtUNsXvV4aPbFUuO', 100, 100, 100, 100, '0000-00-00 00:00:00'),
(33, 'frontendDev', 'frontendDev@dev.eu', '$2y$10$smB.uQlW6n9QbL6B6q7lCOAtWZ6SvhQNX.TkhFiGAi3CwIxBquxoe', 100, 100, 100, 100, '2019-10-12 21:44:27'),
(34, 'backendDev', 'backendDev@dev.pl', '$2y$10$IuDaqvOr6UNs2rBkV2Yj6uLlfMZ5j0oLbMSrn2Wfx/dHZLMVlmtsq', 100, 100, 100, 100, '2019-10-19 21:50:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
